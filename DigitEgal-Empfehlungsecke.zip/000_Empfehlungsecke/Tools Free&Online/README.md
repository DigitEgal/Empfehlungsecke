### **FREE & Online Tools**

**Ohne Account** & **Ohne Installation** nutzbar!

**Privatsphäre**-**respektierend** = dort hochgeladene Dateien werden nicht gespeichert oder analysiert.

**Hinweis**: Einige bieten zudem **optional** downloadbare Tools (pdf24/diagrams)

**Hinweis**: Manche der Tools haben Tracker/Cookies aktiv (siehe deren Datenschutzhinweise)