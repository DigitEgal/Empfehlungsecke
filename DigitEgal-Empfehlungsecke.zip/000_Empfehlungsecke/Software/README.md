**Hier gelistete Software sind Empfehlungen durch mehrjährige Erfahrungen!**

Neben den "**Free Versionen**" proprietärer Software befindet sich in der Sammlung einzig **FOSS & OpenSource Software**
